$(document).ready(function() {

	$('.popup').magnificPopup({
		type: 'ajax',
		alignTop: true,
		overflowY: 'scroll'
	});

	

});